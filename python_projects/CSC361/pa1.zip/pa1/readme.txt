How to use this program:

python webTester.py <URL>

For example: python webTester.py www.uvic.ca 

Can type the URL with or without http://, https://, and www.
The program will account for this.
If the wrong amount of arguments are typed, or the format isn't followed correctly, the program will respond with the correct way to do it.

This program MUST be run on the Linux machines in ECS360 as they are running Python 2.7.18, so this code was built and tested with this version in mind. It will not work
on machines running Python 3.